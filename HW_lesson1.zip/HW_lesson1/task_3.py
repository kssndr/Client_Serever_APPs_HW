"""
Определить, какие из слов «attribute», «класс», «функция», «type» невозможно записать в байтовом
типе.
В байтовом типе можно записать все слова в unicode и слова в ASCII
"""


def main():
    """
    тестирование способа определения типа данных записанного не в ASCII
    """
    words = ['attribute', 'класс', 'функция', 'type']

    print(words)

    for word in words:
        try:
            word.encode('ascii')
        except UnicodeEncodeError:
            print(f"слово '{word}' не возможно записать в байтовом виде по кодировке ASCII")


main()
