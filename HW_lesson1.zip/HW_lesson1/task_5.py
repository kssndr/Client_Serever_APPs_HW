"""
Выполнить пинг веб-ресурсов yandex.ru, youtube.com и преобразовать результаты из байтовового
в строковый тип на кириллице.
"""
import subprocess
from os import name
import chardet


def main_posix():
    """
    тестирование способа преобразования переменных из байтового в строковый тип для
    Юникс подобных ОС
    """
    for site in SITES:
        subproc_ping = subprocess.Popen(['ping', '-c', '1', site],
                                        shell=False, stdout=subprocess.PIPE)
        for line in subproc_ping.stdout:
            print(line)
        print('__'*20, '\n')
        subproc_ping = subprocess.Popen(['ping', '-c', '1', site],
                                        shell=False, stdout=subprocess.PIPE)
        for line in subproc_ping.stdout:
            print(line.decode())
        print('__' * 40, '\n')


def main_not_posix():
    """
    тестирование способа преобразования переменных из байтового в строковый тип для
    не юних подобных ОС
    """
    for site in SITES:
        subproc_ping = subprocess.Popen(['ping', site], stdout=subprocess.PIPE)
        for line in subproc_ping.stdout:
            result = chardet.detect(line)
            print(result)
            line = line.decode(result['encoding']).encode('utf-8')
            print(line.decode('utf-8'))


SITES = ['yandex.ru', 'youtube.com']

if name == 'posix':
    main_posix()
else:
    main_not_posix()
