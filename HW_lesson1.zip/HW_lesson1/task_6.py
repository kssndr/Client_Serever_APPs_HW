"""
Создать текстовый файл t​est_file.txt,​ заполнить его тремя строками:
«сетевое программирование», «сокет», «декоратор». Проверить кодировку
файла по умолчанию. Принудительно открыть файл в формате ​Unicode ​и вывести его содержимое.
"""
import chardet


def main():
    """
    проверка методов создания файлов в заданной кодировки, смена кодировки,
    определения формата файла
    """

    text = ['сетевое программирование', 'сокет', 'декоратор']

    with open('t​est_file.txt', 'w') as file:
        for line in text:
            file.write(f'{line}\n')
    file.close()

    text_in_file = open('t​est_file.txt', 'rb').read()
    print(f'\nкодировка файла {chardet.detect(text_in_file)["encoding"]}')

    print('\nсодержание файла в кодировке UTF-16\n')
    with open('t​est_file.txt', 'r', encoding='utf-16') as file:
        for line in text:
            print(line)


main()
