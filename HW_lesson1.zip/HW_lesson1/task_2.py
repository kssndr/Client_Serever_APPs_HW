"""
Каждое из слов «class», «function», «method» записать в байтовом типе без преобразования
в последовательность кодов (не используя методы ​encode и ​decode)​ и определить тип, содержимое
и длину соответствующих переменных.
"""


def main():
    """
    тестирование метода определения назначения байтового типа данных, проверки типа данных,
    содержимого переменных и длины переменных
    """
    # words_b = [b'class', b'function', b'method']
    words = ['class', 'function', 'method']
    words_b = []
    for word in words:
        word = bytes(word, 'utf-8')
        words_b.append(word)

    for word in words_b:
        print(f'type {type(word)}, {word}, len {len(word)}')


main()
