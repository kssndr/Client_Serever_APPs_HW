"""
Задание на закрепление знаний по модулю ​CSV.​Написать скрипт, осуществляющий выборку
определенных данных из файлов i​nfo_1.txt,​i​nfo_2.txt,​i​nfo_3.txt и формирующий новый
«отчетный» файл в формате ​CSV.
"""
import os
import re
import csv
import chardet


def get_data(file):
    """
    функция:
    1) сбора их файлов данных «Изготовитель системы», «Название ОС», «Код продукта»,
    «Тип системы» в списки os_prod_list,​​os_name_list,​​os_code_list,​​ os_type_list
    2) создания main_data для хранения собранных данных по столбцам отчета в виде списка:
    «Изготовитель системы», «Название ОС», «Код продукта», «Тип системы»
    для каждого найденного файла
    """
    # определение кодировки файла
    content = open(file, 'rb').read()
    format_file = chardet.detect(content)["encoding"]
    file_data = [file]  # хранение найденных искомых данных из файла
    with open(file, 'rb') as from_txt:
        text_in_file = from_txt.readlines()
        for row in text_in_file:
            line = row.decode(format_file)
            for param in SEARCH_PARAM:  # организация построчной идентификации искомых параметров
                if param.encode(format_file) in row:
                    find_param = (
                        ' '.join([t for t in line.split() if t])).split(":")[1]
                    # print((' '.join([t for t in line.split() if t])).split(":")[1])
                    file_data.append(find_param)
    MAIN_DATA.append(file_data)  # выгрузка искомых параметров в главный файл


def write_to_csv(in_csv):
    """
    функция записи собранных данных в csv формате
    """
    with open('main_data.csv', 'w') as f_n:
        data_to_write = csv.writer(f_n)
        for row in in_csv:
            data_to_write.writerow(row)

    with open('main_data.csv') as f_n:
        print(type(f_n.read()))


ALL_FILES = []
SEARCH_PARAM = [
    'Изготовитель ОС',
    'Название ОС',
    'Код продукта',
    'Тип системы']
MAIN_DATA = [['Имя Файла', 'Изготовитель ОС',
              'Название ОС', 'Код продукта', 'Тип системы']]

#  сканирование папки на поиск файлов содержащих искомые данные
for element in os.scandir():
    if element.is_file():
        if re.findall(r'info_\d.txt', element.name):
            ALL_FILES.append(element.name)
# print(all_files) # список всех файлов от куда необходимо собрать данные

# запуск сбора данный по найденным файлам
for files in ALL_FILES:
    get_data(files)
# print(MAIN_DATA)

# выгрузка найденных файлов в csv файл
write_to_csv(MAIN_DATA)
