"""
Задание на закрепление знаний по модулю j​son.​ Есть файл ​orders в формате ​JSON
с информацией о заказах. Написать скрипт, автоматизирующий его заполнение данными. Для этого:
"""
import datetime
import json
from random import randint


def write_order_to_json(new_order):
    """
    функция для ​записи данных (5 параметров) в виде словаря в файл ​orders.json.​
    параметры = товар (i​tem) , количество (​quantity)​, цена (​price)​, покупатель (​buyer)​,
    дата (​date)
    При записи данных указать величину отступа в 4 пробельных символа;
    """
    # запись нового заказа в json формате
    new_order_to_json = json.loads(json.dumps(new_order))
    # print(new_order, type(new_order_to_json))

    # открытие json файла в котором храняться все заказы
    with open('orders.json', 'r') as o_f:
        total_ordrs = json.load(o_f)

    # добавление нового заказа в файл
    total_ordrs['orders'].append(new_order_to_json)

    # запись файла с новым заказом
    with open('orders.json', 'w') as write_file:
        json.dump(total_ordrs, write_file, indent=4)


# генерация нового заказа
DATA_GEN = datetime.date(randint(2005, 2020), randint(1, 12), randint(1, 28))
ORDER = {'item': f'item_{randint(1, 100)}', 'quantity': f'{randint(1, 100)}',
         'price': f'{randint(1, 100)}', 'buyer': f'buyer_{randint(1, 100)}', 'date': f'{DATA_GEN}'}

# добавление заказа в файл
write_order_to_json(ORDER)

# проверка работы через подсчет количества заказов в файле json
with open('orders.json', 'r') as open_file:
    ALL_ORDERS = json.load(open_file)

TOTAL_ORDERS = 0
for order in ALL_ORDERS['orders']:
    TOTAL_ORDERS += 1

print(f'\nВсего заказов {TOTAL_ORDERS} шт.')
