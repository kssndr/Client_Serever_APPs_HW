"""
Задание на закрепление знаний по модулю ​yaml.​ Написать скрипт,
автоматизирующий сохранение данных в файле YAML-формата.
"""
from random import randint
import os
import yaml


def gen_data():
    """
    Подготовка данных для записи в виде словаря, в котором первому
    ключу соответствует список, второму — целое число, третьему —
    вложенный словарь, где значение каждого ключа — это целое число
    с юникод-символом, отсутствующим в кодировке ASCII (например, €);
    """

    # задаем структуру данных
    data_for_yaml = dict.fromkeys(['key_1', 'key_2', 'key_3'])
    list_values_for_key1 = []
    list_to_key3 = {}
    for _ in range(randint(2, 10)):
        list_values_for_key1.append(''.join([chr(randint(1072, 1103))
                                             for x in range(randint(4, 6))]))
        key = randint(256, 3000)
        value = chr(key)
        list_to_key3.update({f'{key}': f'{value}'})

    data_for_yaml['key_1'] = list_values_for_key1
    data_for_yaml['key_2'] = randint(1, 2000)
    data_for_yaml['key_3'] = list_to_key3
    return data_for_yaml


def write_data_to_storage(info):
    """
    Реализовать сохранение данных в файл формата YAML — например, в
    файл file.yaml.​ При этом обеспечить стилизацию файла с помощью
    параметра default_flow_style,​ а также установить возможность
    работы с юникодом: allow_unicode = True;​
    """
    if not os.path.isfile("storage.yaml"):
        with open("storage.yaml", "a") as n_f:
            n_f.write("")
    new_info = yaml.dump(info, allow_unicode=True, default_flow_style=False)
    new_dump = "------\n" + new_info
    with open('storage.yaml', 'a') as w_f:
        w_f.write(new_dump)
    return new_info


#  генерируем очередной блок информации
INFO_TO_YAML = gen_data()

#  записываем в файл очередной блок информации
LAST_ADD_INFO = write_data_to_storage(INFO_TO_YAML)

#  получение последнего внесенного блока данных для проверки совпадения с исходным
with open('storage.yaml', 'r') as r_f:
    ALL_INFO = (r_f.read())
    LAST_INFO = ALL_INFO.split('------\n')[-1]
    Q_ADDED_BLOCKS = len(ALL_INFO.split('------\n'))
    # print(LAST_INFO)

print(f'Статус совпадения внесенных данных с записанными: {LAST_INFO == LAST_ADD_INFO}\n'
      f'количество внесенных блоков информации: {Q_ADDED_BLOCKS}')
